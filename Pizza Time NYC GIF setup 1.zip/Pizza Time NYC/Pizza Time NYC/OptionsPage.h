//
//  OptionsPage.h
//  Pizza Time NYC
//
//  Created by Aditya Narayan on 1/9/16.
//  Copyright © 2016 TTT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OptionsPage : UIViewController <UIWebViewDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end
