//
//  GIFPage.h
//  Pizza Time NYC
//
//  Created by Aditya Narayan on 1/30/16.
//  Copyright © 2016 TTT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GIFPage : UIViewController <UIWebViewDelegate>
@property (strong, nonatomic) IBOutlet UIWebView *webView;

@end
