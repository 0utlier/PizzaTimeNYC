//
//  InfoPage.m
//  Pizza Time NYC
//
//  Created by SUGAR^2 on 12/28/15.
//  Copyright © 2015 TTT. All rights reserved.
//

#import "InfoPage.h"

@implementation InfoPage

@end
