//
//  AddNewPlace.h
//  Pizza Time NYC
//
//  Created by Aditya Narayan on 1/21/16.
//  Copyright © 2016 TTT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MethodManager.h"

@interface AddNewPlace : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *optionsButtonTemp;

@end
